<?php
include 'header.php';
include 'navbar.php';
include 'sidebar.php';
// include 'admin_list.php';
include 'admin_form_add.php';
include 'footer.php';
?>