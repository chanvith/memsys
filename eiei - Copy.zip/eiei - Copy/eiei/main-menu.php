<div class="m-border container mt-3 text-center">
    <h2>Welcome to PHP-DB Web : Chanvith</h2>
    <div class="d-grid gap-2">
        <a href="ex01_insertUser.php" class="btn btn-success">Insert DB with fix data</a>
        <a href="" class="btn btn-primary">Import Connect_DB & Insert Data with SQL</a>
        <a href="ex02_form_insertUser.php" class="btn btn-success">Insert Data with Form by exec</a>
        <a href="ex03_form_insertUser.php" class="btn btn-warning">Insert Data with SQL by Prepared Statement=> :</a>
        <a href="ex04_form_insertUser.php" class="btn btn-warning">Insert Data with SQL by Prepared Statement=> ?</a>
        <a href="" class="btn btn-primary">Insert Data with Form by PDO</a>
        <a href="ex05_showuser.php" class="btn btn-warning">Show User Data</a>
    </div>
</div>